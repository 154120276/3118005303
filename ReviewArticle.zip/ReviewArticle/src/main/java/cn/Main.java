package cn;


import java.math.BigDecimal;


public class Main {
    public static void main(String[] args) {
        ArticleContrast articleContrast = new ArticleContrast();
        String origin=args[0];
        String target=args[1];
        String origintxt="D:\\Ideajava\\IdeaProjects\\ReviewArticle\\src\\main\\resources\\"+origin;
        String targettxt="D:\\Ideajava\\IdeaProjects\\ReviewArticle\\src\\main\\resources\\"+target;

        double cout = articleContrast.cout(origintxt, targettxt);
        BigDecimal b = new BigDecimal(cout);
        cout = b.setScale(4, BigDecimal.ROUND_HALF_UP).doubleValue();
        cout=cout*100;
        System.out.println(origin+"与"+target+"对比的余弦相似度为:"+cout+"%");


    }
}
