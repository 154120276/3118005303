package cn;

import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.common.Term;

import java.io.File;
import java.io.BufferedReader;

import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.*;


public class ArticleContrast{
    /*private final String Separatorcharacter="[.。,，《》“”:？]";*/
    public double cout(String s1,String s2){
        File SourceFile = null;
        File TargetFile = null;
        try {
            SourceFile = new File(s1);
            TargetFile = new File(s2);
        } catch (Exception e) {
            System.out.println("文件读取出错");
            return 0.0;
        }
        StringBuilder originStr=new StringBuilder();
        StringBuilder targetStr=new StringBuilder();
        //选择流
        BufferedReader reader=null;
        /*String Separatorcharacter="[.。,，《》“”:？]";*/
        try {
            reader=new BufferedReader(new FileReader(SourceFile));//true是在后面写不重新创建，false是直接把之前的文件覆盖
            //操作(写出)
            String line=null;
            while((line=reader.readLine())!=null) {
                originStr.append(line);
            }
            reader=new BufferedReader(new FileReader(TargetFile));//true是在后面写不重新创建，false是直接把之前的文件覆盖
            //操作(写出)
            String line1=null;
            while((line1=reader.readLine())!=null) {
                targetStr.append(line1);
            }
           /* String substring = originStr.substring(1,originStr.length());
            String[] split = substring.split(Separatorcharacter);
            for (String s : split) {
                System.out.println(s);
            }*/
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(null!=reader)
                    reader.close();
            } catch (IOException e) {
                // TODO 自动生成的 catch 块
                e.printStackTrace();
            }
        }
        //1、 采用HanLP中文自然语言处理中标准分词进行分词
        List<Term> originList = HanLP.segment(originStr.toString());
        List<Term> targetList = HanLP.segment(targetStr.toString());
        //去除标点符号，代词，助词，连词
        originList.removeIf(term -> term.toString().contains("/w"));
        targetList.removeIf(term -> term.toString().contains("/w"));
        originList.removeIf(term -> term.toString().contains("/r"));
        targetList.removeIf(term -> term.toString().contains("/r"));
        originList.removeIf(term -> term.toString().contains("/c"));
        targetList.removeIf(term -> term.toString().contains("/c"));
        originList.removeIf(term -> term.toString().contains("/u"));
        targetList.removeIf(term -> term.toString().contains("/u"));
        //去重并集
        List<Term> To_re_uniteList = new ArrayList<>(targetList);
        To_re_uniteList.removeAll(originList);
        To_re_uniteList.addAll(originList);
        //将向量数组初始化
        Map<String, Integer> resourcemap=new HashMap<>();
        for (Term term : To_re_uniteList) {
            resourcemap.put(term.toString(),0);
        }
        Map<String, Integer> targetmap=new HashMap<>(resourcemap);
        //赋值两个向量数组
        for (Term term : originList) {
            if (resourcemap.containsKey(term.toString())){
                Integer i = resourcemap.get(term.toString())+1;
                resourcemap.put(term.toString(),i);
            }
        }
        for (Term term : targetList) {
            if (targetmap.containsKey(term.toString())){
                Integer i= resourcemap.get(term.toString())+1;
                targetmap.put(term.toString(),i);
            }
        }
        Removecommonwords(resourcemap);
        Removecommonwords(targetmap);
        double resourcesquare = squares(resourcemap);
        double targetsquare = squares(targetmap);
        double dotMultiplication = DotMultiplication(resourcemap, targetmap);
        double cosinesimilarity = Cosinesimilarity(dotMultiplication, resourcesquare * targetsquare);
        return cosinesimilarity;
    }

    public static double squares(Map<String, Integer> map) {
        double result = 0;
        Set<String> strings = map.keySet();
        for (String string : strings) {
            //System.out.println("词名:"+string+"\t"+"源文件"+"-----频次："+resourcemap.get(string)+"\t"+"目标文件"+"-----频次："+targetmap.get(string));
            double i= (double)map.get(string);
            result+=i*i;
            /*System.out.println(i+"============="+result+"------------"+string);*/
        }
            return Math.sqrt(result);
    }

    public static double DotMultiplication(Map<String, Integer> resourcemap,Map<String, Integer> targetmap){
        double result = 0;
        Set<String> strings = resourcemap.keySet();
        for (String string : strings) {
            //System.out.println("词名:"+string+"\t"+"源文件"+"-----频次："+resourcemap.get(string)+"\t"+"目标文件"+"-----频次："+targetmap.get(string));
            double i= (double)resourcemap.get(string);
            double j= (double)resourcemap.get(string);
            result+=i*j;
        }
        return result;
    }
    public static double Cosinesimilarity(double i,double j){
        return i/j;
    }
    //因为我，的，了，这种常见词频经常出现，所以去除这些常见词频
    public  static Map<String, Integer> Removecommonwords(Map<String, Integer> map){
        for (int i = 0; i <20 ; i++) {
            String target = null;
            int max=0;
            Set<String> strings = map.keySet();
            for (String string : strings) {
                if (map.get(string)>max){
                    max=(map.get(string));
                    target=string;
                }
            }
            map.remove(target);
        }
        return map;
    }
}
