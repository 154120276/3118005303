package org.example;

import static org.junit.Assert.assertTrue;

import cn.ArticleContrast;
import com.hankcs.hanlp.HanLP;
import com.hankcs.hanlp.seg.common.Term;
import org.junit.Test;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.IOException;
import java.net.URL;
import java.util.*;

/**
 * Unit test for simple App.
 */
public class AppTest 
{
    /**
     * Rigorous Test :-)
     */
    @Test
    public void shouldAnswerWithTrue()
    {
        ClassLoader classLoader = ArticleContrast.class.getClassLoader();
        URL resource = classLoader.getResource("orig.txt");
        URL target = classLoader.getResource("orig_0.8_dis_10.txt");
        String resourcePath = resource.getPath();
        String targetPath = target.getPath();
        File SourceFile =new File(resourcePath);
        File TargetFile =new File(targetPath);
        StringBuilder originStr=new StringBuilder();
        StringBuilder targetStr=new StringBuilder();
        //选择流
        BufferedReader reader=null;
        /*String Separatorcharacter="[.。,，《》“”:？]";*/
        try {
            reader=new BufferedReader(new FileReader(SourceFile));//true是在后面写不重新创建，false是直接把之前的文件覆盖
            //操作(写出)
            String line=null;
            while((line=reader.readLine())!=null) {
                originStr.append(line);
            }
            reader=new BufferedReader(new FileReader(TargetFile));//true是在后面写不重新创建，false是直接把之前的文件覆盖
            //操作(写出)
            String line1=null;
            while((line1=reader.readLine())!=null) {
                targetStr.append(line1);
            }
           /* String substring = originStr.substring(1,originStr.length());
            String[] split = substring.split(Separatorcharacter);
            for (String s : split) {
                System.out.println(s);
            }*/
        } catch (IOException e) {
            e.printStackTrace();
        } finally {
            try {
                if(null!=reader)
                    reader.close();
            } catch (IOException e) {
                // TODO 自动生成的 catch 块
                e.printStackTrace();
            }
        }
        //1、 采用HanLP中文自然语言处理中标准分词进行分词
        List<Term> originList = HanLP.segment(originStr.toString());
        List<Term> targetList = HanLP.segment(targetStr.toString());
        originList.removeIf(term -> term.toString().contains("/w"));
        targetList.removeIf(term -> term.toString().contains("/w"));
        System.out.println(originList.size());
        System.out.println(targetList.size());
        //去重并集
        List<Term> To_re_uniteList = new ArrayList<>(targetList);
        To_re_uniteList.removeAll(originList);
        To_re_uniteList.addAll(originList);
        //将向量数组初始化
        Map<String, Integer> resourcemap=new HashMap<>();
        for (Term term : To_re_uniteList) {
            resourcemap.put(term.word,0);
        }
        Map<String, Integer> targetmap=new HashMap<>(resourcemap);
        //赋值两个向量数组
        for (Term term : originList) {
            if (resourcemap.containsKey(term.word)){
                Integer i = resourcemap.get(term.word)+1;
                resourcemap.put(term.word,i);
            }
        }
        for (Term term : targetList) {
            if (targetmap.containsKey(term.word)){
                Integer i= resourcemap.get(term.word)+1;
                targetmap.put(term.word,i);
            }
        }
        Set<String> strings1 = targetmap.keySet();
        for (String s : strings1) {
            System.out.println(s+"-----词频-----"+targetmap.get(s));
        }
        Set<String> strings = resourcemap.keySet();
        List<Integer> resourceInt=new ArrayList<>();
        List<Integer> targetInt=new ArrayList<>();
        for (String string : strings) {
            //System.out.println("词名:"+string+"\t"+"源文件"+"-----频次："+resourcemap.get(string)+"\t"+"目标文件"+"-----频次："+targetmap.get(string));
            resourceInt.add(resourcemap.get(string));
            targetInt.add(targetmap.get(string));
        }

}


}
